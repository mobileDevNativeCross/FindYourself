#import <UIKit/UIKit.h>
#import "ViewController.h"
#import <Umoove/UMooveEngine.h>


@interface AppDelegate : NSObject <UIApplicationDelegate> {
    
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) UMooveEngine *umooveEngine;



@end

