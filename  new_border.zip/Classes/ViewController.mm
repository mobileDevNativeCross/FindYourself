
#import "ViewController.h"
#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>

#import <MediaPlayer/MediaPlayer.h>
#import <AssetsLibrary/AssetsLibrary.h>
@implementation ViewController{
    AVCaptureStillImageOutput* stillImageOutput;
    float fXpos,fYpos;
}

@synthesize captureSession;


- (id)init
{
    
    self = [super init];
    if (self) {
    }
    return self;
    
}

- (void) viewDidLoad {
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    // enable directions
    [appDelegate.umooveEngine enableDirections:YES];
    [appDelegate.umooveEngine setDirectionsSensitivity:100 CenterZone:0 Levels:500 ];

    // enable absolute position
    [appDelegate.umooveEngine enableAbsolutePosition:YES];
    
    // enable cursor
    [appDelegate.umooveEngine enableCursor:YES];
    [appDelegate.umooveEngine setCursorSensitivity:50 HorizontalInitialPosition:.5 VerticalInitialPosition:.5];
    
    // enable speed
    [appDelegate.umooveEngine enableLinearSpeed:YES];

    // set high resolution frame if better accuracy is needed. Uses more CPU.
    [appDelegate.umooveEngine setHighResFrame:TRUE];
    
    // set this view controller as umoove's delegate
    [appDelegate.umooveEngine setUmooveDelegate:self];
    
    // add current capture sessions preview layer in order to see the video.
    AVCaptureVideoPreviewLayer *previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:appDelegate.umooveEngine.captureSession];
    
   [previewLayer setVideoGravity:AVLayerVideoGravityResizeAspect];
//    NSLog(@"")
    previewLayer.frame = self.view.bounds;
    [self.view.layer insertSublayer:previewLayer atIndex:0];
        [self setupCaptureSession];
     [appDelegate.umooveEngine start:NO];
   /* AVCaptureSession *session = [[AVCaptureSession alloc] init];
    session.sessionPreset = AVCaptureSessionPresetMedium;
    

    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //device.position ;
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    [session addInput:input];
   stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys: AVVideoCodecJPEG, AVVideoCodecKey, nil];
    [stillImageOutput setOutputSettings:outputSettings];
    
    [session addOutput:stillImageOutput];
    */
    
}
-(void) setupCaptureSession {
    AVCaptureSession *session = [[AVCaptureSession alloc] init];
    session.sessionPreset = AVCaptureSessionPresetHigh;
    
//    AVCaptureVideoPreviewLayer *captureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer    alloc] initWithSession:session];
//    [self.view.layer addSublayer:captureVideoPreviewLayer];
    
    NSError *error = nil;
    AVCaptureDevice *device = [self frontFacingCameraIfAvailable];
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    if (!input) {
        // Handle the error appropriately.
        NSLog(@"ERROR: trying to open camera: %@", error);
    }
    [session addInput:input];
    
    stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys: AVVideoCodecJPEG, AVVideoCodecKey, nil];
    [stillImageOutput setOutputSettings:outputSettings];
    
    [appDelegate.umooveEngine.captureSession addOutput:stillImageOutput];
    
//    [session startRunning];
}
-(AVCaptureDevice *) frontFacingCameraIfAvailable{
    
    NSArray *videoDevices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    AVCaptureDevice *captureDevice = nil;
    
    for (AVCaptureDevice *device in videoDevices){
        
        if (device.position == AVCaptureDevicePositionFront){
            
            captureDevice = device;
            break;
        }
    }
    
    //  couldn't find one on the front, so just get the default video device.
    if (!captureDevice){
        
        captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    }
    
    return captureDevice;
}

-(void) captureNow {
    AVCaptureConnection *videoConnection = nil;
    for (AVCaptureConnection *connection in stillImageOutput.connections) {
        for (AVCaptureInputPort *port in [connection inputPorts]) {
            if ([[port mediaType] isEqual:AVMediaTypeVideo] ) {
                videoConnection = connection;
                break;
            }
        }
        if (videoConnection) { break; }
    }

    [stillImageOutput captureStillImageAsynchronouslyFromConnection:videoConnection completionHandler: ^(CMSampleBufferRef imageSampleBuffer, NSError *error) {
        
       // NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageSampleBuffer];
        ALAssetsLibraryWriteImageCompletionBlock completionBlock = ^(NSURL *assetURL, NSError *error) {
            if (error) {
             //   if ([[self delegate] respondsToSelector:@selector(captureManager:didFailWithError:)]) {
               //     [[self delegate] captureManager:self didFailWithError:error];
                //}
            }
        };
    if (imageSampleBuffer != NULL) {
            NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageSampleBuffer];
            ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
            
            UIImage *image = [[UIImage alloc] initWithData:imageData];
            [library writeImageToSavedPhotosAlbum:[image CGImage]
                                      orientation:(ALAssetOrientation)[image imageOrientation]
                                  completionBlock:completionBlock];
            [image release];
            
            [library release];
        }
        else
            completionBlock(nil, error);
         }];


}



- (IBAction)detectPressed:(id)sender {
    
    if(((fXpos<-1.7 && fXpos>-3.5)|| ((fXpos>-1.7 && fXpos<1.7))) && ((fYpos >12.0 && fYpos<14.0)|| (fYpos >14.0 && fYpos<17.0))){
         [self captureNow];
    }
    else{
   
        UIAlertView *alert =  [[UIAlertView alloc] initWithTitle:@"Whoops!" message:@"Wrong face position" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [appDelegate.umooveEngine stop];
        [alert show];
    }
}
//FACE ON BORDER = X>=-1,3 && X<=1 Y >10 && Y <13

#pragma mark -- tracker delegate --

// the users angle relative to the center of the device in px.
- (void) UMAbsolutePosition:(float)x :(float)y {
    
    [labelOne setText:[NSString stringWithFormat:@"absolute position %.2f %.2f", x,y]];
    NSLog(@"absolute position %.2f %.2f", x,y);
    fXpos  =x;
    fYpos = y;
    
}

// the directions values resemble a real joystick.
- (void) UMDirectionsUpdate:(int)x :(int)y {
    
    NSLog(@"directions %i %i", x, y);
    [labelTwo setText:[NSString stringWithFormat:@"directions %i %i", x, y]];

}

// the cursor values are the cursors position on the device.
- (void) UMCursorUpdate:(float)x :(float)y {
    
    [labelThree setText:[NSString stringWithFormat:@"cursor %.0f %.0f", x, y]];
    NSLog(@"cursor %f %f", x, y);

}


- (void) UMLinearSpeedUpdate:(float)x :(float)y {
    
    NSLog(@"speed %f %f", x, y);
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        
        [labelFour setText:[NSString stringWithFormat:@"speed %.2f %.2f", x, y]];
        
    }];


}

// the states update is called if a change of state occured
- (void) UMStatesUpdate:(int)state {
   
    switch (state) {
            
        case 1:{
            NSLog(@"detected");
//            alert =   [[UIAlertView alloc]init];
        }
            break;
        case 2:{
             NSLog(@" notdetected");
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView *alert =  [[UIAlertView alloc] initWithTitle:@"Whoops!" message:@"Your face not detected" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
                                [appDelegate.umooveEngine stop];
                [alert show];
            });        }
            break;
        case 3:{
            NSLog(@"lost");
            dispatch_async(dispatch_get_main_queue(), ^{
                 UIAlertView *alert =  [[UIAlertView alloc] initWithTitle:@"Whoops!" message:@"Your face lost" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
                [appDelegate.umooveEngine stop];
                [alert show];
                                          });
         
           

        }
            break;
        default:
            break;
    }
//    [alert show];
}
- (void)alertView:(UIAlertView *)alertView
clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"index==%d",buttonIndex);
    if (buttonIndex == 0){
        //cancel clicked ...do your action
                        [appDelegate.umooveEngine start:NO];
    }else{
        //reset clicked
    }
}

- (void)dealloc {
    [labelOne release];
    [labelTwo release];
    [labelThree release];
    [labelFour release];
    [stillImageOutput release];
    [super dealloc];
}
@end
